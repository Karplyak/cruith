/*
 * GccApplication1.c
 *
 * Created: 04.01.2016 22:52:03
 *  Author: MUSTANG
 */ 


#include <avr/io.h>
#include "i2cmaster.h"
#include "i2c_lcd.h"
#define F_CPU 16000000UL

int main(void)
{
	DDRC = 0b00000111; // DDRB >> 1-out, 0-in
	DDRB = 0b00000000; // DDRB >> 1-out, 0-in
	PORTB = 0b00000111;
	PORTC = 0b00100000;
	char data[16], time[21];
	char light = 0;
	unsigned char step[] = {0b00000001,0b00000010,0b00000100};
	i2c_init();
	lcd_init(LCD_BACKLIGHT_OFF); _delay_ms(200);
	//lcd_init(LCD_CLR);
		int i=0;
	//lcd_goto_xy(0,2);
	lcd_puts_P(PSTR("X:"));
    while(1)
    {	lcd_puts_P(PSTR("X:"));_delay_ms(200);
		
		 if(!(PINB & (1<<PINB0) == 1)) //If switch is pressed
		 {
			 PORTD |= (1<<PD0); //Turns ON LED
		//	 lcd_light(LCD_BACKLIGHT_OFF);
			 _delay_ms(200); //3 second delay
			// PORTC &= ~(1<<PC0); //Turns OFF LED
			if(light==1)
			{//lcd_init(LCD_BACKLIGHT_ON);
				lcd_puts_P(PSTR("Y:"));
				light = 0;
				lcd_light(LCD_BACKLIGHT_ON);
			} else {
				lcd_light(LCD_BACKLIGHT_OFF);
				lcd_puts_P(PSTR("X:"));
				light = 1;
			}
			
		 }
		
	//	lcd_goto_xy(0,2);
	   // lcd_puts_P(PSTR("X:"));
		//_delay_ms(10000);
        //TODO:: Please write your application code 
		/*if (PINB.0==0) {
			_delay_ms(200);
			PORTC.0=1;
		};*/
		if((PINB & (1<<PINB1) == 1)) //If switch is pressed
		{
			switch(i)
			{
				case 0:
				PORTC = step[0];
				i++;
				break;
				case 1:
				PORTC = step[1];
				i++;
				break;
				case 2:
				PORTC = step[2];
				i=0;
				break;
			}
			
		}
    }
}